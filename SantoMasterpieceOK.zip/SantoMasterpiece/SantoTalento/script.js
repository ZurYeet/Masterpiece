let punteggioG = 0;
let punteggioB = 0;
let carteGiocatore = {
  1: 4,
  2: 3,
  3: 2,
  4: 2,
  5: 1,
};

let carteBot = {
  1: 4,
  2: 3,
  3: 2,
  4: 2,
  5: 1,
};

function restartGame() {
  punteggioG = 0;
  punteggioB = 0;
  carteGiocatore = {
    1: 4,
    2: 3,
    3: 2,
    4: 2,
    5: 1,
  };
  carteBot = {
    1: 4,
    2: 3,
    3: 2,
    4: 2,
    5: 1,
  };
  document.getElementById("punteggioG").innerText = "Punteggio Giocatore: 0";
  document.getElementById("punteggioB").innerText = "Punteggio Bot: 0";
  document.getElementById("result").innerText = "";
  document.getElementById("playerCards").innerHTML = "";
  document.getElementById("botCards").innerHTML = "";
  document.getElementById("playAgain").style.display = "none";
  for (let card in carteGiocatore) {
    const cardCount = carteGiocatore[card];
    for (let i = 0; i < cardCount; i++) {
      const button = document.createElement("button");
      button.innerText = card;
      button.classList.add("card-button");
      button.addEventListener("click", () => {
        playCard(card);
        button.remove(); // Remove the button when it is clicked
      });
      document.getElementById("playerCards").appendChild(button);
    }
  }
}

function playCard(playerCard) {
  let botCard = Math.floor(Math.random() * 5) + 1;
  while (carteBot[botCard] === 0) {
    botCard = Math.floor(Math.random() * 5) + 1;
  }
  const cartaGvalore = parseInt(playerCard);
  const cartaBvalore = botCard;

  carteGiocatore[cartaGvalore]--;
  carteBot[cartaBvalore]--;

  const playerCardElement = document.createElement("div");
  playerCardElement.innerText = `Giocatore: ${cartaGvalore}`;
  document.getElementById("playerCards").appendChild(playerCardElement);

  const botCardElement = document.createElement("div");
  botCardElement.innerText = `Bot: ${cartaBvalore}`;
  document.getElementById("botCards").appendChild(botCardElement);

  if (cartaGvalore > cartaBvalore) {
    punteggioG++;
  } else if (cartaGvalore < cartaBvalore) {
    punteggioB++;
  }

  document.getElementById("punteggioG").innerText = `Punteggio Giocatore: ${punteggioG}`;
  document.getElementById("punteggioB").innerText = `Punteggio Bot: ${punteggioB}`;

  if (punteggioG === 5 || punteggioB === 5 || Object.values(carteGiocatore).every((val) => val === 0)){
    document.getElementById("result").innerText =
      punteggioG === 5 ? "Hai vinto!" : "Hai perso!";
    document.getElementById("playAgain").style.display = "block";
  }
}

// Generate player card buttons
for (let card in carteGiocatore) {
  const cardCount = carteGiocatore[card];
  for (let i = 0; i < cardCount; i++) {
    const button = document.createElement("button");
    button.innerText = card;
    button.classList.add("card-button");
    button.addEventListener("click", () => {
      playCard(card);
      console.log(carteBot);
      button.remove(); // Remove the button when it is clicked
    });
    document.getElementById("playerCards").appendChild(button);
  }
}
